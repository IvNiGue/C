#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <math.h>

//variable para guardar la elecion del usuario
char eleccion, caracter_blanco=219;

//variables para definir el tama�o de la matriz y el numero de minas
int filas, columnas, minas;

//cordenadas para ir moviendose por la matriz
int cordx, cordy, fila=65, columna=49, x, y;

//coordenadas para la mini-matriz
int cordz, cordw;

//variables para las coordenadas aleatorias
int numero_a, numero_a2;

int main()
{
    srand (time (NULL));

    printf("Busca Minas ------ Hecho por Ivan Nieto Guerrero\n\n");
    printf("Buenas estimado usuario, esta a punto de empezar el juego de busca minas\n");
    printf("Favor de ingresar cualquier caracter para continuar\n\n");
    fflush(stdin);
    scanf("%c", &eleccion);

    do
    {
        printf("Favor de seleccionar el modo del juego, o si desea salir digite S \n");
        printf("Facil (tablero 10x10) --- Digite F\n");
        printf("Dificil (tablero 20x30) --- Digite D\n");
        fflush(stdin);
        scanf("%c", &eleccion);

        switch (eleccion)
        {
            case 'F':{

                printf("\nModo Facil (tablero 10x10)\n\n");

                filas=12;
                columnas=12;
                minas=20;

                char tablero[filas][columnas], tablero_jugador[filas][columnas];

                int end_game=1, coincidencias=0, contar_banderas=20;

                tablero[0][0]='+';

                for(cordy=1; cordy<columnas; cordy++)
                {
                    tablero[0][cordy]=fila;
                    fila=fila+1;
                }
                fila=65;

                for(cordy=0; cordy<columnas; cordy++)
                {
                    tablero[11][cordy]='-';

                }


                for(cordx=0; cordx<filas; cordx++)
                {
                    tablero[cordx][11]='|';

                }


                for(cordx=1; cordx<filas-2; cordx++)
                {
                    tablero[cordx][0]=columna;
                    columna=columna+1;
                }
                columna=49;

                tablero[10][0]='A';

                for(cordx=1; cordx<filas-1; cordx++)
                {
                    for(cordy=1; cordy<columnas-1; cordy++)
                    {

                        tablero[cordx][cordy]=219;

                    }
                }

                /*for(cordx=0; cordx<filas; cordx++)
                {
                    for(cordy=0; cordy<columnas; cordy++)
                    {
                        printf("%c  ", tablero[cordx][cordy]);
                    }
                    printf("\n\n");
                }*/

                int contador_bombas=0;

                while(contador_bombas<minas)
                {
                    numero_a= 1 + rand() % (10 + 1 - 1);
                    numero_a2= 1 + rand() % (10 + 1 - 1);

                    //printf("El numero aleatorio es %d y %d \n", numero_a, numero_a2);

                    cordx=numero_a;
                    cordy=numero_a2;

                    if (tablero[cordx][cordy]!='*')
                    {
                        tablero[cordx][cordy]='*';
                        contador_bombas=contador_bombas+1;
                    }

                    cordx=0;
                    cordy=0;
                }


                printf("\n\n");
                /*for(cordx=0; cordx<filas; cordx++)
                {
                    for(cordy=0; cordy<columnas; cordy++)
                    {
                        printf("%c  ", tablero[cordx][cordy]);
                    }
                    printf("\n\n");
                }*/

                char bombas_alrededor=48;

                for(cordx=1; cordx<filas-1; cordx++)
                {
                    for(cordy=1; cordy<columnas-1; cordy++)
                    {
                        if(tablero[cordx][cordy]!='*')
                        {

                            for(cordw=(cordx-1); cordw<=(cordx+1); cordw++)
                            {
                                for(cordz=(cordy-1); cordz<=(cordy+1); cordz++)
                                {
                                    if(tablero[cordw][cordz]=='*')
                                    {
                                        bombas_alrededor=bombas_alrededor+1;
                                    }
                                }
                            }
                            tablero[cordx][cordy]=bombas_alrededor;
                            bombas_alrededor=48;

                        }
                    }
                }

                printf("\n\n");
                /*for(cordx=0; cordx<filas; cordx++)
                {
                    for(cordy=0; cordy<columnas; cordy++)
                    {
                        printf("%c  ", tablero[cordx][cordy]);
                    }
                    printf("\n\n");
                }*/

                tablero_jugador[0][0]='+';

                for(cordy=1; cordy<columnas; cordy++)
                {
                    tablero_jugador[0][cordy]=fila;
                    fila=fila+1;
                }
                fila=65;

                for(cordy=0; cordy<columnas; cordy++)
                {
                    tablero_jugador[11][cordy]='-';

                }


                for(cordx=0; cordx<filas; cordx++)
                {
                    tablero_jugador[cordx][11]='|';

                }


                for(cordx=1; cordx<filas-2; cordx++)
                {
                    tablero_jugador[cordx][0]=columna;
                    columna=columna+1;
                }
                columna=49;

                tablero_jugador[10][0]=65;

                for(cordx=1; cordx<filas-1; cordx++)
                {
                    for(cordy=1; cordy<columnas-1; cordy++)
                    {

                        tablero_jugador[cordx][cordy]=219;

                    }
                }


                while (end_game>0)
                {
                    system("cls");

                    printf("\n\n");

                    int mi_cont=0;

                    for(cordx=0; cordx<filas; cordx++)
                    {
                        for(cordy=0; cordy<columnas; cordy++)
                        {
                            printf("%c  ", tablero_jugador[cordx][cordy]);

                            if(tablero_jugador[cordx][cordy]==-37)
                            {
                                mi_cont++;
                            }
                        }
                        printf("\n\n");
                    }

                    if(coincidencias==20 && mi_cont==0)
                    {
                        printf("GANASTE\n");
                        end_game=end_game-1;
                        printf("Si desea salir, digite S, en caso contrario digite cualquier otro caracter\n\n");
                        fflush(stdin);
                        scanf("%c", &eleccion);
                    }
                    printf("\n\n");
                    printf("Banderas: %d --- Casillas cerradas: %d\n\n", contar_banderas, mi_cont);
                    printf("Ingrese la coordenada en x (x son las filas y van desde 1 - 10)\n");
                    scanf("%d", &x);
                    printf("Ingrese la coordenada en y (y son las columnas y van desde 1 - 10)\n");
                    scanf("%d", &y);

                    printf("�Que desea realizar?\n");
                    printf("Abrir casilla(A), marcar casilla(M), desmarcar casilla(T)\n");
                    fflush(stdin);
                    scanf("%c", &eleccion);

                    switch(eleccion)
                    {
                        case 'A':{

                            if(x<11 && y<11)
                            {

                            if(tablero_jugador[x][y]=='/')
                            {
                               tablero_jugador[x][y]=tablero[x][y];

                               if(tablero_jugador[x][y]!='*')
                                {
                                contar_banderas=contar_banderas+1;

                                if(tablero[x][y]=='*')
                                {
                                    coincidencias=coincidencias-1;
                                }

                                }
                            }
                            tablero_jugador[x][y]=tablero[x][y];

                            if(tablero_jugador[x][y]=='*')
                            {
                                system("cls");

                                for(cordx=0; cordx<filas; cordx++)
                                {
                                    for(cordy=0; cordy<columnas; cordy++)
                                    {
                                        tablero_jugador[cordx][cordy]=tablero[cordx][cordy];
                                        /*if(tablero_jugador[cordx][cordy]==-37)
                                        {
                                            mi_cont++;
                                        }*/
                                        printf("%c  ", tablero_jugador[cordx][cordy]);
                                    }
                                    printf("\n\n");
                                }

                                printf("TOCASTE UNA MINA\n");
                                end_game=end_game-1;
                            }
                            if(tablero_jugador[x][y]=='0')
                            {
                                for(cordx=x; cordx<x+1; cordx++)
                                {
                                    for(cordy=y; cordy<y+1; cordy++)
                                    {

                                        for(cordw=(cordx-1); cordw<=(cordx+1); cordw++)
                                        {
                                            for(cordz=(cordy-1); cordz<=(cordy+1); cordz++)
                                            {

                                                tablero_jugador[cordw][cordz]=tablero[cordw][cordz];

                                            }
                                        }

                                    }
                                }
                            }
                        }

                        }break;

                        case 'M':{

                            if(x>0 && y>0)
                            {

                                if(x<11 && y<11)
                                {
                                    if((int)tablero_jugador[x][y]==-37)
                                    {

                                        if(contar_banderas>0 && tablero_jugador[x][y]!='/')
                                        {
                                            tablero_jugador[x][y]='/';

                                            if(tablero[x][y]=='*')
                                            {
                                                coincidencias=coincidencias+1;
                                            }
                                            contar_banderas=contar_banderas-1;
                                        }
                                    }
                                }
                            }


                        }break;

                        case 'T':{

                            if(x<11 && y<11)
                            {


                            if(tablero_jugador[x][y]=='/' && contar_banderas<20)
                            {
                                contar_banderas=contar_banderas+1;
                                tablero_jugador[x][y]=219;

                                if(tablero[x][y]=='*')
                                {
                                    coincidencias=coincidencias-1;
                                }
                            }
                        }

                        }break;


                    }



                }
                end_game=1;
                coincidencias=0;
                contar_banderas=20;



            }break;

            case 'D':{

                printf("\nModo Dificil (tablero 20x30)\n\n");

                filas=22;
                columnas=32;
                minas=300;

                char tablero[filas][columnas], tablero_jugador[filas][columnas];

                int end_game=1, coincidencias=0, contar_banderas=300;

                tablero[0][0]='+';

                fila=49;
                for(cordy=1; cordy<=9; cordy++)
                {
                    tablero[0][cordy]=fila;
                    fila=fila+1;
                }
                fila=65;

                for(cordy=10; cordy<columnas; cordy++)
                {
                    tablero[0][cordy]=fila;
                    fila=fila+1;
                }
                fila=65;

                for(cordy=0; cordy<columnas; cordy++)
                {
                    tablero[21][cordy]='-';

                }


                for(cordx=0; cordx<filas; cordx++)
                {
                    tablero[cordx][31]='|';

                }


                for(cordx=1; cordx<=9; cordx++)
                {
                    tablero[cordx][0]=columna;
                    columna=columna+1;
                }
                columna=49;

                columna=65;
                for(cordx=10; cordx<filas-2; cordx++)
                {
                    tablero[cordx][0]=columna;
                    columna=columna+1;
                }
                columna=49;
                for(cordx=1; cordx<filas-1; cordx++)
                {
                    for(cordy=1; cordy<columnas-1; cordy++)
                    {

                        tablero[cordx][cordy]=219;

                    }
                }

                /*for(cordx=0; cordx<filas; cordx++)
                {
                    for(cordy=0; cordy<columnas; cordy++)
                    {
                        printf("%c  ", tablero[cordx][cordy]);
                    }
                    printf("\n\n");
                }*/

                int contador_bombas=0;

                while(contador_bombas<minas)
                {
                    numero_a= 1 + rand() % (20 + 1 - 1);
                    numero_a2= 1 + rand() % (30 + 1 - 1);

                    //printf("El numero aleatorio es %d y %d \n", numero_a, numero_a2);

                    cordx=numero_a;
                    cordy=numero_a2;

                    if (tablero[cordx][cordy]!='*')
                    {
                        tablero[cordx][cordy]='*';
                        contador_bombas=contador_bombas+1;
                    }

                    cordx=0;
                    cordy=0;
                }


                printf("\n\n");
                /*for(cordx=0; cordx<filas; cordx++)
                {
                    for(cordy=0; cordy<columnas; cordy++)
                    {
                        printf("%c  ", tablero[cordx][cordy]);
                    }
                    printf("\n\n");
                }*/

                char bombas_alrededor=48;

                for(cordx=1; cordx<filas-1; cordx++)
                {
                    for(cordy=1; cordy<columnas-1; cordy++)
                    {
                        if(tablero[cordx][cordy]!='*')
                        {

                            for(cordw=(cordx-1); cordw<=(cordx+1); cordw++)
                            {
                                for(cordz=(cordy-1); cordz<=(cordy+1); cordz++)
                                {
                                    if(tablero[cordw][cordz]=='*')
                                    {
                                        bombas_alrededor=bombas_alrededor+1;
                                    }
                                }
                            }
                            tablero[cordx][cordy]=bombas_alrededor;
                            bombas_alrededor=48;

                        }
                    }
                }

                printf("\n\n");
                /*for(cordx=0; cordx<filas; cordx++)
                {
                    for(cordy=0; cordy<columnas; cordy++)
                    {
                        printf("%c  ", tablero[cordx][cordy]);
                    }
                    printf("\n\n");
                }*/

                tablero_jugador[0][0]='+';

                fila=49;
                for(cordy=1; cordy<=9; cordy++)
                {
                    tablero_jugador[0][cordy]=fila;
                    fila=fila+1;
                }
                fila=65;

                for(cordy=10; cordy<columnas; cordy++)
                {
                    tablero_jugador[0][cordy]=fila;
                    fila=fila+1;
                }
                fila=65;

                for(cordy=0; cordy<columnas; cordy++)
                {
                    tablero_jugador[21][cordy]='-';

                }


                for(cordx=0; cordx<filas; cordx++)
                {
                    tablero_jugador[cordx][31]='|';

                }


                for(cordx=1; cordx<=9; cordx++)
                {
                    tablero_jugador[cordx][0]=columna;
                    columna=columna+1;
                }
                columna=49;

                columna=65;
                for(cordx=10; cordx<filas-1; cordx++)
                {
                    tablero_jugador[cordx][0]=columna;
                    columna=columna+1;
                }
                columna=49;
                for(cordx=1; cordx<filas-1; cordx++)
                {
                    for(cordy=1; cordy<columnas-1; cordy++)
                    {

                        tablero_jugador[cordx][cordy]=219;

                    }
                }


                while (end_game>0)
                {
                    system("cls");

                    printf("\n\n");

                    int mi_cont=0;

                    for(cordx=0; cordx<filas; cordx++)
                    {
                        for(cordy=0; cordy<columnas; cordy++)
                        {
                            printf("%c  ", tablero_jugador[cordx][cordy]);

                            if(tablero_jugador[cordx][cordy]==-37)
                            {
                                mi_cont++;
                            }
                        }
                        printf("\n\n");
                    }

                    if(coincidencias==300 && mi_cont==0)
                    {
                        printf("GANASTE\n");
                        end_game=end_game-1;
                        printf("Si desea salir, digite S, en caso contrario digite cualquier otro caracter\n\n");
                        fflush(stdin);
                        scanf("%c", &eleccion);
                    }
                    printf("\n\n");
                    printf("Banderas: %d --- Casillas cerradas: %d\n\n", contar_banderas, mi_cont);
                    printf("Ingrese la coordenada en x (x son las filas y van desde 1 - 20)\n");
                    scanf("%d", &x);
                    printf("Ingrese la coordenada en y (y son las columnas y van desde 1 - 30)\n");
                    scanf("%d", &y);

                    printf("�Que desea realizar?\n");
                    printf("Abrir casilla(A), marcar casilla(M), desmarcar casilla(T)\n");
                    fflush(stdin);
                    scanf("%c", &eleccion);

                    switch(eleccion)
                    {
                        case 'A':{

                            if(x<21 && y<31)
                            {

                            if(tablero_jugador[x][y]=='/')
                            {
                               tablero_jugador[x][y]=tablero[x][y];

                               if(tablero_jugador[x][y]!='*')
                                {
                                contar_banderas=contar_banderas+1;

                                if(tablero[x][y]=='*')
                                {
                                    coincidencias=coincidencias-1;
                                }

                                }
                            }
                            tablero_jugador[x][y]=tablero[x][y];

                            if(tablero_jugador[x][y]=='*')
                            {
                                system("cls");

                                for(cordx=0; cordx<filas; cordx++)
                                {
                                    for(cordy=0; cordy<columnas; cordy++)
                                    {
                                        tablero_jugador[cordx][cordy]=tablero[cordx][cordy];
                                        /*if(tablero_jugador[cordx][cordy]==-37)
                                        {
                                            mi_cont++;
                                        }*/
                                        printf("%c  ", tablero_jugador[cordx][cordy]);
                                    }
                                    printf("\n\n");
                                }

                                printf("TOCASTE UNA MINA\n");
                                end_game=end_game-1;
                            }
                            if(tablero_jugador[x][y]=='0')
                            {
                                for(cordx=x; cordx<x+1; cordx++)
                                {
                                    for(cordy=y; cordy<y+1; cordy++)
                                    {

                                        for(cordw=(cordx-1); cordw<=(cordx+1); cordw++)
                                        {
                                            for(cordz=(cordy-1); cordz<=(cordy+1); cordz++)
                                            {

                                                tablero_jugador[cordw][cordz]=tablero[cordw][cordz];

                                            }
                                        }

                                    }
                                }
                            }
                        }

                        }break;

                        case 'M':{

                            if(x>0 && y>0)
                            {

                                if(x<21 && y<31)
                                {
                                    if((int)tablero_jugador[x][y]==-37)
                                    {

                                        if(contar_banderas>0 && tablero_jugador[x][y]!='/')
                                        {
                                            tablero_jugador[x][y]='/';

                                            if(tablero[x][y]=='*')
                                            {
                                                coincidencias=coincidencias+1;
                                            }
                                            contar_banderas=contar_banderas-1;
                                        }
                                    }
                                }
                            }


                        }break;

                        case 'T':{

                            if(x<21 && y<31)
                            {


                            if(tablero_jugador[x][y]=='/' && contar_banderas<300)
                            {
                                contar_banderas=contar_banderas+1;
                                tablero_jugador[x][y]=219;

                                if(tablero[x][y]=='*')
                                {
                                    coincidencias=coincidencias-1;
                                }
                            }
                        }

                        }break;


                    }



                }
                end_game=1;
                coincidencias=0;
                contar_banderas=300;



            }break;
        }
    }

    while (eleccion!='S');
    return 0;
}
