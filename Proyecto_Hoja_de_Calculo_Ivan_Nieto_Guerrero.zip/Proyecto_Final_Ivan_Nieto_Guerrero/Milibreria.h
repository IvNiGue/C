#ifndef MILIBRERIA_H_INCLUDED
#define MILIBRERIA_H_INCLUDED

#include <string.h>

void bienvenida()
{
    printf("Buenas mi estimado usuario, soy un programa destinado al apoyo de creacion de boletas de calificacion\n");
    printf("Tengo la capacidad de generar boletas mediante la informacion que se ingrese, corregir alguna boleta ya generada, etc.\n\n");
    printf("1.- Si desea vaciar informacion en una boleta y generar un archivo, favor de digitar I\n");
    printf("2.- Si desea recuperar una boleta ya generada con anterioridad, favor de digitar R\n");
}

void correccion(char *palabra1, char *salida1)
{
    int medida1;

    medida1=strlen(palabra1);

    if(medida1>10)
    {
        palabra1[10]='\0';
    }else if(medida1<10){

        while(medida1<10)
        {
            strcat(palabra1, "_");
            medida1 = strlen(palabra1);
        }

    }
    strcpy(salida1, palabra1);

}



float promedio(float sum, int parciales)
{
    float divis;

    divis = sum / parciales;

    return divis;
}

void regla(float prom, int menor_5, int menor_6, int mayor_6, int parciales, char *salida)
{
    if(prom>=6 && mayor_6==parciales)
    {
        strcpy(salida, "Aprobado");

    }else if(prom>=6 && mayor_6<parciales)
    {
        strcpy(salida, "Extra___");

    }else if(prom<6 && menor_6==parciales)
    {
        strcpy(salida, "Extra___");

    }else if(prom<6 && prom>=5 && menor_5==0)
    {
        strcpy(salida, "Extra___");

    }else if(prom>=6 && menor_5>0)
    {
        strcpy(salida, "Extra___");

    }else if(prom<6 && prom>=5 && menor_5>0)
    {
        strcpy(salida, "Titulo__");

    }
    else if(prom<5)
    {
        strcpy(salida, "Titulo__");
    }
}


#endif // MILIBRERIA_H_INCLUDED
