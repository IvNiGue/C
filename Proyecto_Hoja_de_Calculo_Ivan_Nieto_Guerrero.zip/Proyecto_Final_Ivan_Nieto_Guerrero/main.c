#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <math.h>
#include "Milibreria.h"

//variable de eleccion
char eleccion;

//variables para la creacion de boletas
int cant_alumnos, cant_parciales, codigo_grupo;
char nombre_materia[20], grupo[20], nombre_archivo[20];
char enc_filas[20];
int columnas, filas;
float calf_parcial;
float suma, division;


//variables para moverse por la matriz
int cordx, cordy, k, l;
char sustituir[20];

int main()
{
    FILE* archivo;

    char linea[1000];

    srand(time(NULL));

    printf("-----Boleta de calificaciones----\n");
    printf("\n\n---------------------------\n\n\n");
    printf("----(Realizado por: Ivan Nieto Guerrero)----\n");
    printf("\n\n---------------------------\n\n\n");
    printf("Digite cualquier caracter para continuar\n");
    fflush(stdin);
    scanf("%c", &eleccion);

    do
    {
        system("cls");

        bienvenida();
        fflush(stdin);
        scanf("%c", &eleccion);

        switch(eleccion)
        {
            case 'I':
                {
                    system("cls");

                    codigo_grupo=0 + rand() % (10000 + 1 - 0);

                    printf("Usted desea generar una boleta de calificaciones\n\n");
                    printf("Favor de ingresar el nombre de la materia\n");
                    scanf("%s", nombre_materia);
                    printf("Favor de ingresar el grupo que va a registar (Utilice guiones bajos en vez de espacios)\n");
                    scanf("%s", grupo);
                    printf("Favor de ingresar la cantidad de alumnos a evaluar (No mas de 100)\n");
                    scanf("%d", &cant_alumnos);
                    printf("Favor de ingresar la cantidad de parciales a evaluar (No mas de 10)\n");
                    scanf("%d", &cant_parciales);

                    printf("\n-------------------\n\n");

                    printf("El nombre de la materia es: %s , el grupo es: %s \n", nombre_materia, grupo);
                    printf("La cantidad de alumnos a evaluar es: %d y la cantidad de parciales es: %d \n", cant_alumnos, cant_parciales);
                    printf("�Son correctos los datos?\n");
                    printf("(Si lo son digite S, caso contrario digite N)\n");
                    fflush(stdin);
                    scanf("%c", &eleccion);

                    while(cant_alumnos<=0 || cant_alumnos>=101 || cant_parciales<=0 || cant_parciales>=11)
                    {
                        printf("La cantidad de parciales o alumnos no es valida, favor de volver a ingresar los datos\n");
                        printf("Favor de ingresar la cantidad de alumnos a evaluar (No mas de 100)\n");
                        scanf("%d", &cant_alumnos);
                        printf("Favor de ingresar la cantidad de parciales a evaluar (No mas de 10)\n");
                        scanf("%d", &cant_parciales);
                    }

                    while(eleccion=='N')
                    {

                        printf("Que dato desea corregir?\n");
                        printf("(Si desea corregir el nombre digite N, el numero de alumnos digite A, el numero de parciales digite P)\n");
                        printf("(Si desea corregir el grupo digite M)\n");
                        fflush(stdin);
                        scanf("%c", &eleccion);

                        switch (eleccion)
                        {
                            case 'N':
                                {
                                   printf("Favor de ingresar el nombre de la materia\n");
                                   scanf("%s", nombre_materia);
                                }break;

                            case 'M':
                                {
                                   printf("Favor de ingresar el grupo que va a registar (Utilice guiones bajos en vez de espacios)\n");
                                   scanf("%s", grupo);
                                }break;

                            case 'A':
                                {
                                   printf("Favor de ingresar la cantidad de alumnos a evaluar\n");
                                   scanf("%d", &cant_alumnos);
                                }break;

                            case 'P':
                                {
                                    printf("Favor de ingresar la cantidad de parciales a evaluar\n");
                                    scanf("%d", &cant_parciales);
                                }break;
                            default:
                                {
                                    printf("Elegiste una opcion no se�alada\n");
                                    system("PAUSE");
                                }break;
                        }


                        printf("\n-------------------\n\n");

                        printf("El nombre de la materia es: %s , el grupo es: %s \n", nombre_materia, grupo);
                        printf("La cantidad de alumnos a evaluar es: %d y la cantidad de parciales es: %d \n", cant_alumnos, cant_parciales);
                        printf("�Son correctos los datos?\n");
                        printf("(Si lo son digite S, caso contrario digite N)\n");
                        fflush(stdin);
                        scanf("%c", &eleccion);
                    }

                    if(eleccion=='S')
                    {
                        system("cls");

                        filas=cant_alumnos+1;
                        columnas=cant_parciales+6;

                        //boleta
                        char boleta[filas][columnas][50];

                        //encabezado
                        strcpy(boleta[0][0], "Nom_Alumno");
                        strcpy(boleta[0][1], "Ape_Patern");
                        strcpy(boleta[0][2], "Ape_Matern");

                        for(cordy=3; cordy<columnas-3; cordy++)
                        {
                            itoa(cordy-2, enc_filas, 10);

                            strcpy(boleta[0][cordy], "Parcial");
                            strcat(boleta[0][cordy], "_");
                            strcat(boleta[0][cordy], enc_filas);
                        }
                        //fin encabezado

                        for(cordx=1; cordx<cant_alumnos+1; cordx++)
                        {
                            printf("Ingrese el nombre del alumno\n");
                            scanf("%s", boleta[cordx][0]);
                            printf("Ingrese el apellido paterno del alumno\n");
                            scanf("%s", boleta[cordx][1]);
                            printf("Ingrese el apellido materno del alumno\n");
                            scanf("%s", boleta[cordx][2]);

                            correccion(boleta[cordx][0], boleta[cordx][0]);
                            correccion(boleta[cordx][1], boleta[cordx][1]);
                            correccion(boleta[cordx][2], boleta[cordx][2]);

                            printf("\n\n");

                        }


                        for(cordx=1; cordx<filas; cordx++)
                        {
                            system("cls");
                            for(cordy=3; cordy<columnas-3; cordy++)
                            {
                                printf("Ingrese la calificacion parcial %d del alumno: %s %s\n", cordy-2, boleta[cordx][0], boleta[cordx][1]);
                                scanf("%f", &calf_parcial);

                                while(calf_parcial<0 || calf_parcial>10)
                                {
                                    printf("Calificacion no valida\n");
                                    printf("Ingrese la calificacion parcial %d del alumno: %s %s\n", cordy-2, boleta[cordx][0], boleta[cordx][1]);
                                    fflush(stdin);
                                    scanf("%f", &calf_parcial);
                                }

                                sprintf(boleta[cordx][cordy], "%.5f", calf_parcial);
                            }
                        }

                        //promedio

                        strcpy(boleta[0][columnas-3], "Promedio");

                        suma=0;

                        for(cordx=1; cordx<filas; cordx++)
                        {
                            for(cordy=3; cordy<columnas-3; cordy++)
                            {
                                suma = suma + atof(boleta[cordx][cordy]);
                            }

                            division = promedio(suma, cant_parciales);

                            suma=0;

                            sprintf(boleta[cordx][columnas-3], "%.5f", division);
                        }

                        //fin promedio
                        //inicio de la regla

                        int parc_men_5=0, parc_men_6=0, parc_may_6=0;
                        float auxiliar, condicion;

                        strcpy(boleta[0][columnas-2], "Estatus");

                        for(cordx=1; cordx<filas; cordx++)
                        {
                            for(cordy=3; cordy<columnas-3; cordy++)
                            {
                                auxiliar = atof(boleta[cordx][cordy]);
                                if(auxiliar<5)
                                {
                                    parc_men_5++;
                                }else if(auxiliar<6 && auxiliar>=5)
                                {
                                    parc_men_6++;
                                }else if(auxiliar>=6)
                                {
                                    parc_may_6++;
                                }

                            }

                            condicion = atof(boleta[cordx][columnas-3]);

                            regla(condicion, parc_men_5, parc_men_6, parc_may_6, cant_parciales, boleta[cordx][columnas-2]);

                            parc_may_6=0;
                            parc_men_5=0;
                            parc_men_6=0;
                        }

                        //fin de la regla

                        //inicio de parciales a recuperar

                        strcpy(boleta[0][columnas-1], "Parciales_a_Recuperar");

                        int comparacion;
                        float parcial;
                        char aprobado[20];

                        strcpy(aprobado, "Aprobado");

                        for(cordx=1; cordx<filas; cordx++)
                        {
                            comparacion = strcmp(aprobado, boleta[cordx][columnas-2]);

                            strcpy(boleta[cordx][columnas-1], ":");

                            if(comparacion!=0)
                            {
                                for(cordy=3; cordy<columnas-3; cordy++)
                                {
                                    parcial = atof(boleta[cordx][cordy]);

                                    if(parcial<6)
                                    {
                                       strcat(boleta[cordx][columnas-1], boleta[0][cordy]);
                                       strcat(boleta[cordx][columnas-1], "-");
                                    }
                                }


                            }else if(comparacion==0)
                            {
                                strcat(boleta[cordx][columnas-1], "Ninguna");
                            }
                        }

                        //fin de parciales a recuperar

                        //inicio de promedio mayor y menor, procentaje de aprobacion

                        int actual, siguiente, contador=0;
                        float apoyo1, apoyo2, mayor_prom, menor_prom, porcentaje;
                        char copia[filas][1][20], auxiliar1[20];

                        for(cordx=0; cordx<filas; cordx++)
                        {
                            strcpy(copia[cordx][0], boleta[cordx][columnas-3]);
                        }

                        for(actual=1; actual<filas; actual++)
                        {
                            for(siguiente=actual+1; siguiente<filas; siguiente++)
                            {
                                apoyo1 = atof(copia[actual][0]);
                                apoyo2 = atof(copia[siguiente][0]);

                                if(apoyo1<=apoyo2)
                                {
                                    strcpy(auxiliar1, copia[actual][0]);
                                    strcpy(copia[actual][0], copia[siguiente][0]);
                                    strcpy(copia[siguiente][0], auxiliar1);
                                }
                            }
                        }

                        mayor_prom = atof (copia[1][0]);
                        menor_prom = atof (copia[filas-1][0]);

                        for(cordx=1; cordx<filas; cordx++)
                        {
                            comparacion = strcmp(aprobado, boleta[cordx][columnas-2]);

                            if(comparacion==0)
                            {
                                contador++;
                            }
                        }

                        porcentaje = (contador*100)/cant_alumnos;
                        contador=0;

                        //fin de promedio mayor y menor, procentaje de aprobacion

                        system("cls");


                        printf("Nombre de la materia: %s \n", nombre_materia);
                        printf("Grupo: %s \n", grupo);
                        printf("Codigo del grupo: %d\n\n", codigo_grupo);
                        for(cordx=0; cordx<filas; cordx++)
                        {
                            for(cordy=0; cordy<columnas; cordy++)
                            {
                                printf("%s \t", boleta[cordx][cordy]);
                            }
                            printf("\n");
                        }
                        printf("\nEl mayor promedio es: %.2f y el menor es: %.2f \n", mayor_prom, menor_prom);
                        printf("El porcentaje de aprobacion del salon es del %.2f \n\n", porcentaje);

                        //buscar y remplazar

                        float guardar_num;

                        printf("Son correctos los datos?\n");
                        printf("N en caso de que no, o digite cualquier otro caracter en caso de que si)\n");
                        fflush(stdin);
                        scanf("%c", &eleccion);

                        while(eleccion=='N')
                        {
                            printf("\nIngrese en que fila se encuentra el dato a corregir (2 - %d)\n", filas);
                            scanf("%d", &k);
                            printf("\nIngrese en que columna se encuentra el dato a corregir (1 - %d)\n", columnas);
                            scanf("%d", &l);

                            k=k-1;
                            l=l-1;

                            if(k>0 && l<columnas-3 && l>-1)
                            {
                                printf("El dato a corregir es %s \n", boleta[k][l]);
                                printf("Porque quiere sustituir el dato?\n");
                                scanf("%s", sustituir);

                                if (l>2 && l<columnas-3)
                                {
                                    guardar_num = atof(sustituir);

                                    while(guardar_num<0 || guardar_num>10)
                                    {
                                        printf("Calificacion no valida\n");
                                        printf("Ingrese la calificacion parcial %s del alumno: %s %s\n", boleta[0][l], boleta[k][0], boleta[k][1]);
                                        scanf("%s", sustituir);

                                        guardar_num = atof(sustituir);
                                    }

                                    sprintf(boleta[k][l], "%.5f", guardar_num);

                                    for(cordy=3; cordy<columnas-3; cordy++)
                                    {
                                        suma = suma + atof(boleta[k][cordy]);
                                    }

                                    division = promedio(suma, cant_parciales);

                                    suma=0;

                                    sprintf(boleta[k][columnas-3], "%.5f", division);

                                    for(cordy=3; cordy<columnas-3; cordy++)
                                    {
                                        auxiliar = atof(boleta[k][cordy]);
                                        if(auxiliar<5)
                                        {
                                            parc_men_5++;
                                        }else if(auxiliar<6 && auxiliar>=5)
                                        {
                                            parc_men_6++;
                                        }else if(auxiliar>=6)
                                        {
                                            parc_may_6++;
                                        }

                                    }

                                    condicion = atof(boleta[k][columnas-3]);

                                    regla(condicion, parc_men_5, parc_men_6, parc_may_6, cant_parciales, boleta[k][columnas-2]);

                                    parc_may_6=0;
                                    parc_men_5=0;
                                    parc_men_6=0;

                                    comparacion = strcmp(aprobado, boleta[k][columnas-2]);

                                    strcpy(boleta[k][columnas-1], ":");

                                    if(comparacion!=0)
                                    {
                                        for(cordy=3; cordy<columnas-3; cordy++)
                                        {
                                            parcial = atof(boleta[k][cordy]);

                                            if(parcial<6)
                                            {
                                               strcat(boleta[k][columnas-1], boleta[0][cordy]);
                                               strcat(boleta[k][columnas-1], "-");
                                            }
                                        }


                                    }else if(comparacion==0)
                                    {
                                        strcat(boleta[k][columnas-1], "Ninguna");
                                    }

                                }else if(l>=0 && l<=2)
                                {
                                    correccion(sustituir, sustituir);

                                    strcpy(boleta[k][l], sustituir);
                                }

                                system("cls");

                            }else if(k<=0 || l>=columnas-3 || l<=-1)
                            {
                                printf("Una de las cordenadas no es aceptable\n\n");
                                system("PAUSE");
                                system("cls");
                            }

                            printf("Nombre de la materia: %s \n", nombre_materia);
                            printf("Grupo: %s \n", grupo);
                            printf("Codigo del grupo: %d\n\n", codigo_grupo);
                            for(cordx=0; cordx<filas; cordx++)
                            {
                                for(cordy=0; cordy<columnas; cordy++)
                                {
                                    printf("%s \t", boleta[cordx][cordy]);
                                }
                                printf("\n");
                            }
                            printf("\nEl mayor promedio es: %.2f y el menor es: %.2f \n", mayor_prom, menor_prom);
                            printf("El porcentaje de aprobacion del salon es del %.2f \n\n", porcentaje);

                            printf("Son correctos los datos?\n");
                            printf("N en caso de que no, o digite cualquier otro caracter en caso de que si)\n");
                            fflush(stdin);
                            scanf("%c", &eleccion);
                        }

                        //fin buscar y remplazar

                        //ordenamiento

                        printf("Desea ordenar la tabla? (S en caso de que si, o digite cualquier otro caracter en caso de que no)\n");
                        fflush(stdin);
                        scanf("%c", &eleccion);

                        if(eleccion=='S')
                        {
                            printf("Como desea ordenar?\n");
                            printf("(ascendente en base al promedio (A), descendete en base al promedio(D))\n");
                            printf("(ascendente en base al nombre (E), descendete en base al nombre(O))\n");
                            fflush(stdin);
                            scanf("%c", &eleccion);

                            switch(eleccion)
                            {
                                case 'D':{
                                    for(actual=1; actual<filas; actual++)
                                    {
                                        for(siguiente=actual+1; siguiente<filas; siguiente++)
                                        {
                                            apoyo1 = atof(boleta[actual][columnas-3]);
                                            apoyo2 = atof(boleta[siguiente][columnas-3]);

                                            if(apoyo1<=apoyo2)
                                            {
                                                for(cordx=0; cordx<columnas; cordx++)
                                                {
                                                    strcpy(auxiliar1, boleta[actual][cordx]);
                                                    strcpy(boleta[actual][cordx], boleta[siguiente][cordx]);
                                                    strcpy(boleta[siguiente][cordx], auxiliar1);
                                                }
                                            }
                                        }
                                    }

                                }break;

                                case 'A':{
                                    for(actual=1; actual<filas; actual++)
                                    {
                                        for(siguiente=actual+1; siguiente<filas; siguiente++)
                                        {

                                            apoyo1 = atof(boleta[actual][columnas-3]);
                                            apoyo2 = atof(boleta[siguiente][columnas-3]);

                                            if(apoyo1>=apoyo2)
                                            {
                                                for(cordx=0; cordx<columnas; cordx++)
                                                {
                                                    strcpy(auxiliar1, boleta[actual][cordx]);
                                                    strcpy(boleta[actual][cordx], boleta[siguiente][cordx]);
                                                    strcpy(boleta[siguiente][cordx], auxiliar1);
                                                }
                                            }
                                        }
                                    }

                                }break;

                                case 'E':{
                                    for(actual=1; actual<filas; actual++)
                                    {
                                        for(siguiente=actual+1; siguiente<filas; siguiente++)
                                        {
                                            comparacion = strcmp(boleta[actual][0], boleta[siguiente][0]);

                                            if(comparacion>=0)
                                            {
                                                for(cordx=0; cordx<columnas; cordx++)
                                                {
                                                    strcpy(auxiliar1, boleta[actual][cordx]);
                                                    strcpy(boleta[actual][cordx], boleta[siguiente][cordx]);
                                                    strcpy(boleta[siguiente][cordx], auxiliar1);
                                                }
                                            }
                                        }
                                    }

                                }break;

                                case 'O':{
                                    for(actual=1; actual<filas; actual++)
                                    {
                                        for(siguiente=actual+1; siguiente<filas; siguiente++)
                                        {
                                            comparacion = strcmp(boleta[actual][0], boleta[siguiente][0]);

                                            if(comparacion<=0)
                                            {
                                                for(cordx=0; cordx<columnas; cordx++)
                                                {
                                                    strcpy(auxiliar1, boleta[actual][cordx]);
                                                    strcpy(boleta[actual][cordx], boleta[siguiente][cordx]);
                                                    strcpy(boleta[siguiente][cordx], auxiliar1);
                                                }
                                            }
                                        }
                                    }

                                }break;

                                default:
                                    {
                                        printf("No elegiste una de las opciones marcadas, no se ordeno la boleta\n");
                                        system("PAUSE");
                                    }break;
                            }

                            system("cls");


                            printf("Nombre de la materia: %s \n\n", nombre_materia);
                            printf("Grupo: %s \n", grupo);
                            printf("Codigo del grupo: %d\n\n", codigo_grupo);
                            for(cordx=0; cordx<filas; cordx++)
                            {
                                for(cordy=0; cordy<columnas; cordy++)
                                {
                                    printf("%s \t", boleta[cordx][cordy]);
                                }
                                printf("\n");
                            }
                            printf("\nEl mayor promedio es: %.2f y el menor es: %.2f \n", mayor_prom, menor_prom);
                            printf("El porcentaje de aprobacion del salon es del %.2f \n", porcentaje);

                            }
                        //fin ordenamiento
                        printf("\nDeseas guardar el archivo?\n");
                        printf("(Digite cualquier caracter para guardar, en caso de que no desee guardar digite N)\n");
                        fflush(stdin);
                        scanf("%c", &eleccion);

                        if(eleccion!='N')
                        {
                            char temporal[20];

                            printf("Ingrese el nombre del archivo\n");
                            scanf("%s", nombre_archivo);
                            strcat(nombre_archivo, ".txt");

                            printf("El nombre del archivo va a ser: %s \n", nombre_archivo);

                            archivo = fopen(nombre_archivo, "at");

                            fputs("Nombre de la materia: ", archivo);
                            fputs(nombre_materia, archivo);
                            fputs("\n", archivo);

                            fputs("Grupo: ", archivo);
                            fputs(grupo, archivo);
                            fputs("\n", archivo);

                            fputs("Codigo del grupo: ", archivo);
                            itoa(codigo_grupo, temporal, 10);
                            fputs(temporal, archivo);
                            fputs("\n", archivo);

                            for(cordx=0; cordx<filas; cordx++)
                            {
                                for(cordy=0; cordy<columnas; cordy++)
                                {
                                    fputs(boleta[cordx][cordy], archivo);
                                    fputs(" \t", archivo);
                                }
                                fputs("\n", archivo);
                            }

                            fputs("\n", archivo);
                            fputs("El mayor promedio es: ", archivo);
                            sprintf(temporal, "%.2f", mayor_prom);
                            fputs(temporal, archivo);
                            fputs(" y el menor es: ", archivo);
                            sprintf(temporal, "%.2f", menor_prom);
                            fputs(temporal, archivo);
                            fputs("\n", archivo);

                            fputs("El porcentaje de aprobacion del salon es del ", archivo);
                            sprintf(temporal, "%.2f", porcentaje);
                            fputs(temporal, archivo);
                            fputs("\n\n", archivo);


                            system("PAUSE");

                            fclose(archivo);
                        }
                    }

                }break;

            case 'R':
                {
                    system("cls");

                    printf("Ingrese el nombre del archivo\n");
                    scanf("%s", nombre_archivo);

                    archivo = fopen(nombre_archivo, "rt");

                    if(archivo==NULL)
                    {
                        printf("El archivo no existe\n");
                        system("PAUSE");
                        exit(1);
                    }

                    while( !feof(archivo))
                    {
                        fgets(linea, 1000, archivo);
                        printf("%s", linea);
                    }

                    system("PAUSE");

                    fclose(archivo);

                }break;
                default:
                    {
                        printf("Elegiste una opcion no se�alada\n");
                        system("PAUSE");
                    }break;
        }

    }

    while(eleccion!='S');
    return 0;
}
